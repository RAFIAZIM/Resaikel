package dao; // Ensure this matches the directory structure
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Domestic;

public class DomesticDAO {
    // DAO methods here...

    private static final String JDBC_URL = "jdbc:derby://localhost:1527/customer_resaikel";
    private static final String JDBC_USER = "app";
    private static final String JDBC_PASSWORD = "app";

    public void addRecord(Domestic domestic) throws SQLException {
        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             PreparedStatement ps = conn.prepareStatement("INSERT INTO APP.DOMESTIC (NAME, ADDRESS, PHONENUMBER, DAY) VALUES (?, ?, ?, ?)")) {
            ps.setString(1, domestic.getName());
            ps.setString(2, domestic.getAddress());
            ps.setString(3, domestic.getPhone());
            ps.setString(4, domestic.getDay());
            ps.executeUpdate();

            // Retrieve the auto-generated keys (if any)
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                int id = rs.getInt(1);
                domestic.setId(id); // Set the generated ID in the model object
            }
        }
    }

    public void updateRecord(Domestic domestic) throws SQLException {
        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             PreparedStatement ps = conn.prepareStatement("UPDATE APP.DOMESTIC SET NAME=?, ADDRESS=?, PHONENUMBER=?, DAY=? WHERE ID=?")) {
            ps.setString(1, domestic.getName());
            ps.setString(2, domestic.getAddress());
            ps.setString(3, domestic.getPhone());
            ps.setString(4, domestic.getDay());
            ps.setInt(5, domestic.getId());
            ps.executeUpdate();
        }
    }

    public void deleteRecord(int id) throws SQLException {
        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             PreparedStatement ps = conn.prepareStatement("DELETE FROM APP.DOMESTIC WHERE ID=?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public Domestic getRecordById(int id) throws SQLException {
        Domestic domestic = null;
        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM APP.DOMESTIC WHERE ID=?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    domestic = new Domestic(
                        rs.getInt("ID"),
                        rs.getString("NAME"),
                        rs.getString("ADDRESS"),
                        rs.getString("PHONENUMBER"),
                        rs.getString("DAY")
                    );
                }
            }
        }
        return domestic;
    }

    public List<Domestic> getAllRecords() throws SQLException {
        List<Domestic> domestics = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM APP.DOMESTIC")) {
            while (rs.next()) {
                Domestic domestic = new Domestic(
                    rs.getInt("ID"),
                    rs.getString("NAME"),
                    rs.getString("ADDRESS"),
                    rs.getString("PHONENUMBER"),
                    rs.getString("DAY")
                );
                domestics.add(domestic);
            }
        }
        return domestics;
    }
}
