package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import model.ThreeRService; // Import ThreeRService model

public class ThreeRServiceDAO {
    private static final String JDBC_URL = "jdbc:derby://localhost:1527/customer_resaikel";
    private static final String JDBC_USER = "app";
    private static final String JDBC_PASSWORD = "app";

    public void addRecord(ThreeRService service) throws SQLException {
        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             PreparedStatement ps = conn.prepareStatement("INSERT INTO APP.THREERSERVICE (NAME, ADDRESS, PHONENUMBER, DATE, TIME, ITEM) VALUES (?, ?, ?, ?, ?, ?)")) {
            ps.setString(1, service.getName());
            ps.setString(2, service.getAddress());
            ps.setString(3, service.getPhone());
            ps.setDate(4, java.sql.Date.valueOf(service.getDate()));
            ps.setString(5, service.getTime());
            ps.setString(6, service.getItem());
            ps.executeUpdate();
        }
    }

    public void updateRecord(ThreeRService service) throws SQLException {
        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             PreparedStatement ps = conn.prepareStatement("UPDATE APP.THREERSERVICE SET NAME=?, ADDRESS=?, PHONENUMBER=?, DATE=?, TIME=?, ITEM=? WHERE ID=?")) {
            ps.setString(1, service.getName());
            ps.setString(2, service.getAddress());
            ps.setString(3, service.getPhone());
            ps.setDate(4, java.sql.Date.valueOf(service.getDate()));
            ps.setString(5, service.getTime());
            ps.setString(6, service.getItem());
            ps.setInt(7, service.getId());
            ps.executeUpdate();
        }
    }

    public void deleteRecord(int id) throws SQLException {
        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             PreparedStatement ps = conn.prepareStatement("DELETE FROM APP.THREERSERVICE WHERE ID=?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public ThreeRService getRecordById(int id) throws SQLException {
        ThreeRService service = null;
        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM APP.THREERSERVICE WHERE ID=?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    service = new ThreeRService(
                        rs.getInt("ID"),
                        rs.getString("NAME"),
                        rs.getString("ADDRESS"),
                        rs.getString("PHONENUMBER"),
                        rs.getDate("DATE").toString(),
                        rs.getString("TIME"),
                        rs.getString("ITEM")
                    );
                }
            }
        }
        return service;
    }

    public List<ThreeRService> getAllRecords() throws SQLException {
        List<ThreeRService> services = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM APP.THREERSERVICE")) {
            while (rs.next()) {
                ThreeRService service = new ThreeRService(
                    rs.getInt("ID"),
                    rs.getString("NAME"),
                    rs.getString("ADDRESS"),
                    rs.getString("PHONENUMBER"),
                    rs.getDate("DATE").toString(),
                    rs.getString("TIME"),
                    rs.getString("ITEM")
                );
                services.add(service);
            }
        }
        return services;
    }
}

