import dao.DomesticDAO;
import dao.DomesticDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Domestic;

@WebServlet("/DomesticServlet")
public class DomesticServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private DomesticDAO dao = new DomesticDAO();


    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        try {
            switch (action) {
                case "add":
                    addRecord(request, response);
                    break;
                case "update":
                    updateRecord(request, response);
                    break;
                case "delete":
                    deleteRecord(request, response);
                    break;
                default:
                    response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid action");
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String idStr = request.getParameter("id");
        if (idStr != null) {
            try {
                int id = Integer.parseInt(idStr);
                Domestic record = dao.getRecordById(id);
                if (record != null) {
                    request.setAttribute("record", record);
                    request.getRequestDispatcher("editForm.jsp").forward(request, response);
                } else {
                    response.sendError(HttpServletResponse.SC_NOT_FOUND, "Record not found");
                }
            } catch (NumberFormatException | SQLException e) {
                e.printStackTrace();
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid ID format");
            }
        } else {
            
            try {
                displayRecords(response);
            } catch (SQLException ex) {
                Logger.getLogger(DomesticServlet.class.getName()).log(Level.SEVERE, null, ex);
            }
           
        }
    }

    private void addRecord(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
        String name = request.getParameter("name");
        String address = request.getParameter("address");
        String phone = request.getParameter("phone");
        String day = request.getParameter("day");

        Domestic domestic = new Domestic(name, address, phone, day);
        dao.addRecord(domestic);

        // If you want to return updated records to display, you can call displayRecords(response);
        // or send a success message back to the client via AJAX.

        // For simplicity, assuming success in this example
        response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write("Record added successfully");
    }

    private void updateRecord(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
        String idStr = request.getParameter("id");
        String name = request.getParameter("name");
        String address = request.getParameter("address");
        String phone = request.getParameter("phone");
        String day = request.getParameter("day");

        if (idStr == null || name == null || address == null || phone == null || day == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing parameter(s)");
            return;
        }

        int id;
        try {
            id = Integer.parseInt(idStr);
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid ID format");
            return;
        }

        Domestic domestic = new Domestic(id, name, address, phone, day);
        dao.updateRecord(domestic);
        displayRecords(response);
    }

    private void deleteRecord(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        dao.deleteRecord(id);
    }

    private void displayRecords(HttpServletResponse response) throws IOException, SQLException {
        List<Domestic> records = dao.getAllRecords();
        try (PrintWriter out = response.getWriter()) {
            for (Domestic record : records) {
                out.println("<tr>");
                out.println("<td>" + record.getId() + "</td>");
                out.println("<td>" + record.getName() + "</td>");
                out.println("<td>" + record.getAddress() + "</td>");
                out.println("<td>" + record.getPhone() + "</td>");
                out.println("<td>" + record.getDay() + "</td>");
                out.println("<td>");
                out.println("<button onclick='editRecord(" + record.getId() + ")'>Edit</button>");
                out.println("<button onclick='deleteRecord(" + record.getId() + ")'>Delete</button>");
                out.println("</td>");
                out.println("</tr>");
            }
        }
        
    }
}
