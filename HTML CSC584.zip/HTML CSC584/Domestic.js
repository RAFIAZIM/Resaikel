let idCounter = 1;

    function addItem() {
        const name = document.getElementById('name').value;
        const address = document.getElementById('address').value;
        const phone = document.getElementById('phone').value;
        const day = document.getElementById('day').value;

        if (name && address && phone && day) {
            const tableBody = document.getElementById('addedItems');
            const newRow = tableBody.insertRow();
            newRow.setAttribute('data-id', idCounter);
            newRow.onclick = function () {
                document.getElementById('editIndex').value = this.getAttribute('data-id');
                populateEditForm(this);
            };
            const idCell = newRow.insertCell();
            const nameCell = newRow.insertCell();
            const addressCell = newRow.insertCell();
            const phoneCell = newRow.insertCell();
            const dayCell = newRow.insertCell();
            const actionCell = newRow.insertCell();

            idCell.textContent = idCounter;
            nameCell.textContent = name;
            addressCell.textContent = address;
            phoneCell.textContent = phone;
            dayCell.textContent = day;

            const editButton = document.createElement('button');
            editButton.textContent = 'Edit';
            editButton.onclick = function (event) {
                event.stopPropagation();
                document.getElementById('editIndex').value = newRow.getAttribute('data-id');
                populateEditForm(newRow);
            };
            actionCell.appendChild(editButton);

            const deleteButton = document.createElement('button');
            deleteButton.textContent = 'Delete';
            deleteButton.onclick = function (event) {
                event.stopPropagation();
                newRow.remove();
            };
            actionCell.appendChild(deleteButton);

            idCounter++;

            resetForm();
        } else {
            alert('Please fill in all fields.');
        }
    }

    function populateEditForm(row) {
        document.getElementById('name').value = row.cells[1].textContent;
        document.getElementById('address').value = row.cells[2].textContent;
        document.getElementById('phone').value = row.cells[3].textContent;
        document.getElementById('day').value = row.cells[4].textContent;
        document.getElementById('addButton').style.display = 'none';
        document.getElementById('updateButton').style.display = 'inline-block';
    }

    function updateItem() {
        const editIndex = document.getElementById('editIndex').value;
        const name = document.getElementById('name').value;
        const address = document.getElementById('address').value;
        const phone = document.getElementById('phone').value;
        const day = document.getElementById('day').value;

        if (name && address && phone && day) {
            const tableBody = document.getElementById('addedItems');
            const rows = tableBody.getElementsByTagName('tr');
            for (let i = 0; i < rows.length; i++) {
                if (rows[i].getAttribute('data-id') === editIndex) {
                    rows[i].cells[1].textContent = name;
                    rows[i].cells[2].textContent = address;
                    rows[i].cells[3].textContent = phone;
                    rows[i].cells[4].textContent = day;
                    break;
                }
            }

            resetForm();
        } else {
            alert('Please fill in all fields.');
        }
    }

    function resetForm() {
        document.getElementById('editIndex').value = '';
        document.getElementById('name').value = '';
        document.getElementById('address').value = '';
        document.getElementById('phone').value = '';
        document.getElementById('day').value = '';
        document.getElementById('addButton').style.display = 'inline-block';
        document.getElementById('updateButton').style.display = 'none';
    }