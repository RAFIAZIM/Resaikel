import DAO.DomesticWasteDAO;
import bean.DomesticWaste;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/DomesticServlet")
public class DomesticServlet extends HttpServlet {
    private DomesticWasteDAO dao;

    @Override
    public void init() throws ServletException {
        dao = new DomesticWasteDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("add".equals(action)) {
            String name = request.getParameter("name");
            String address = request.getParameter("address");
            String phone = request.getParameter("phone");
            String day = request.getParameter("day");

            DomesticWaste waste = new DomesticWaste();
            waste.setName(name);
            waste.setAddress(address);
            waste.setPhone(phone);
            waste.setDay(day);

            try {
                dao.addDomesticWaste(waste);
                response.sendRedirect("Domestic.jsp");
            } catch (Exception e) {
                throw new ServletException(e);
            }
        } else if ("delete".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            try {
                dao.deleteDomesticWaste(id);
                response.sendRedirect("Domestic.jsp");
            } catch (Exception e) {
                throw new ServletException(e);
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            List<DomesticWaste> wastes = dao.getAllDomesticWaste();
            PrintWriter out = response.getWriter();
            for (DomesticWaste waste : wastes) {
                out.println("<tr>");
                out.println("<td>" + waste.getId() + "</td>");
                out.println("<td>" + waste.getName() + "</td>");
                out.println("<td>" + waste.getAddress() + "</td>");
                out.println("<td>" + waste.getPhone() + "</td>");
                out.println("<td>" + waste.getDay() + "</td>");
                out.println("<td><button onclick=\"editRecord(" + waste.getId() + ")\">Edit</button>");
                out.println("<button onclick=\"deleteRecord(" + waste.getId() + ")\">Delete</button></td>");
                out.println("</tr>");
            }
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }
}
