package registerpage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String username = request.getParameter("Username");
        String password = request.getParameter("psw");

        if (username == null || username.isEmpty() || password == null || password.isEmpty()) {
            response.getWriter().println("Username and password must not be empty.");
            return;
        }

        String jdbcUrl = "jdbc:derby://localhost:1527/customer_resaikel;user=app;password=app";
        String sql = "INSERT INTO APP.USERS(USERNAME, PASSWORD) VALUES (?, ?)";

        try (Connection connection = DriverManager.getConnection(jdbcUrl);
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            preparedStatement.executeUpdate();

            response.sendRedirect("login.jsp?success=true");

        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("Registration failed. Error: " + e.getMessage());
        }
    }
}
