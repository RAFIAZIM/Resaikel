package DAO;

import bean.DomesticWaste;
import database.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DomesticWasteDAO {

    public void addDomesticWaste(DomesticWaste waste) throws SQLException, ClassNotFoundException {
        String sql = "INSERT INTO DomesticWaste (name, address, phone, day) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, waste.getName());
            stmt.setString(2, waste.getAddress());
            stmt.setString(3, waste.getPhone());
            stmt.setString(4, waste.getDay());
            stmt.executeUpdate();
        }
    }

    public List<DomesticWaste> getAllDomesticWaste() throws SQLException, ClassNotFoundException {
        List<DomesticWaste> list = new ArrayList<>();
        String sql = "SELECT * FROM DomesticWaste";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                DomesticWaste waste = new DomesticWaste();
                waste.setId(rs.getInt("id"));
                waste.setName(rs.getString("name"));
                waste.setAddress(rs.getString("address"));
                waste.setPhone(rs.getString("phone"));
                waste.setDay(rs.getString("day"));
                list.add(waste);
            }
        }
        return list;
    }

    public void deleteDomesticWaste(int id) throws SQLException, ClassNotFoundException {
        String sql = "DELETE FROM DomesticWaste WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
}
