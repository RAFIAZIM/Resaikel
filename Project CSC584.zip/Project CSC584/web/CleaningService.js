let items = [];

        // Function to add a new record
        function addItem() {
            let name = document.getElementById("name").value.trim();
            let address = document.getElementById("address").value.trim();
            let phone = document.getElementById("phone").value.trim();
            let date = document.getElementById("date").value.trim();
            let service = document.getElementById("service").value.trim();
            let payment = document.getElementById("payment").value.trim(); // Get selected payment method

            if (name === "" || address === "" || phone === "" || date === "" || service === "" || payment === "") {
                alert("Please fill in all fields.");
                return;
            }

            let newItem = {
                id: generateId(), // Generate unique ID
                name: name,
                address: address,
                phone: phone,
                date: date,
                service: service,
                payment: payment // Add payment method to newItem object
            };

            items.push(newItem);
            displayItems();
            clearForm();
        }

        // Function to generate unique ID
        function generateId() {
            return '_' + Math.random().toString(36).substr(2, 9);
        }

        // Function to display items in the table
        function displayItems() {
            let tableBody = document.getElementById("addedItems");
            tableBody.innerHTML = "";

            items.forEach(function(item, index) {
                let row = document.createElement("tr");
                row.innerHTML = `
                    <td>${index + 1}</td> <!-- Use index + 1 as ID -->
                    <td>${item.name}</td>
                    <td>${item.address}</td>
                    <td>${item.phone}</td>
                    <td>${item.date}</td>
                    <td>${item.service}</td>
                    <td>${item.payment}</td> <!-- Display payment method -->
                    <td>
                        <button onclick="editItem(${index})">Edit</button> <!-- Pass index -->
                        <button onclick="deleteItem(${index})">Delete</button> <!-- Pass index -->
                    </td>
                `;
                tableBody.appendChild(row);
            });
        }

        // Function to clear the form fields
        function clearForm() {
            document.getElementById("name").value = "";
            document.getElementById("address").value = "";
            document.getElementById("phone").value = "";
            document.getElementById("date").value = "";
            document.getElementById("service").value = "";
            document.getElementById("payment").value = "Cash"; // Set default payment method to "Cash"
        }

        // Function to edit an item
        function editItem(index) {
            let selectedItem = items[index];
            if (selectedItem) {
                document.getElementById("name").value = selectedItem.name;
                document.getElementById("address").value = selectedItem.address;
                document.getElementById("phone").value = selectedItem.phone;
                document.getElementById("date").value = selectedItem.date;
                document.getElementById("service").value = selectedItem.service;
                document.getElementById("payment").value = selectedItem.payment; // Set payment method

                // Show the update button and hide the add button
                document.getElementById("addButton").style.display = "none";
                document.getElementById("updateButton").style.display = "inline-block";

                // Store the index of the item being edited
                document.getElementById("editIndex").value = index;
            }
        }

        // Function to update an item
        function updateItem() {
            let index = document.getElementById("editIndex").value;
            let selectedItem = items[index];
            if (selectedItem) {
                selectedItem.name = document.getElementById("name").value.trim();
                selectedItem.address = document.getElementById("address").value.trim();
                selectedItem.phone = document.getElementById("phone").value.trim();
                selectedItem.date = document.getElementById("date").value.trim();
                selectedItem.service = document.getElementById("service").value.trim();
                selectedItem.payment = document.getElementById("payment").value.trim(); // Update payment method

                displayItems();
                clearForm();

                // Show the add button and hide the update button
                document.getElementById("addButton").style.display = "inline-block";
                document.getElementById("updateButton").style.display = "none";
            }
        }

        // Function to delete an item
        function deleteItem(index) {
            items.splice(index, 1);
            displayItems();
        }

        // Initial display of items
        displayItems();


