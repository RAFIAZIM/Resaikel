import dao.CleaningServicesDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.CleaningService;

@WebServlet("/CleaningServicesServlet")
public class CleaningServicesServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private CleaningServicesDAO dao = new CleaningServicesDAO();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        try {
            switch (action) {
                case "add":
                    addRecord(request, response);
                    break;
                case "update":
                    updateRecord(request, response);
                    break;
                case "delete":
                    deleteRecord(request, response);
                    break;
                default:
                    response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid action");
                    break;
            }
            displayRecords(response);
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String idStr = request.getParameter("id");
        if (idStr != null) {
            try {
                int id = Integer.parseInt(idStr);
                CleaningService record = dao.getRecordById(id);
                if (record != null) {
                    request.setAttribute("record", record);
                    request.getRequestDispatcher("editForm.jsp").forward(request, response);
                } else {
                    response.sendError(HttpServletResponse.SC_NOT_FOUND, "Record not found");
                }
            } catch (NumberFormatException | SQLException e) {
                e.printStackTrace();
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid ID format");
            }
        } else {
            displayRecords(response);
        }
    }

    private void addRecord(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
        String name = request.getParameter("name");
        String address = request.getParameter("address");
        String phone = request.getParameter("phone");
        String date = request.getParameter("date");
        String service = request.getParameter("service");
        String payment = request.getParameter("payment");

        CleaningService cleaningService = new CleaningService(name, address, phone, date, service, payment);
        dao.addRecord(cleaningService);
    }

    private void updateRecord(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
    String idStr = request.getParameter("id");
    String name = request.getParameter("name");
    String address = request.getParameter("address");
    String phone = request.getParameter("phone");
    String date = request.getParameter("date");
    String service = request.getParameter("service");
    String payment = request.getParameter("payment");

    if (idStr == null || name == null || address == null || phone == null || date == null || service == null || payment == null) {
        response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing parameter(s)");
        return;
    }

    int id;
    try {
        id = Integer.parseInt(idStr);
    } catch (NumberFormatException e) {
        response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid ID format");
        return;
    }

    CleaningService cleaningService = new CleaningService(id, name, address, phone, date, service, payment);
    dao.updateRecord(cleaningService);
    displayRecords(response);
}

    private void deleteRecord(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        dao.deleteRecord(id);
    }

    private void displayRecords(HttpServletResponse response) throws IOException {
        try {
            List<CleaningService> records = dao.getAllRecords();
            try (PrintWriter out = response.getWriter()) {
                for (CleaningService record : records) {
                    out.println("<tr>");
                    out.println("<td>" + record.getId() + "</td>");
                    out.println("<td>" + record.getName() + "</td>");
                    out.println("<td>" + record.getAddress() + "</td>");
                    out.println("<td>" + record.getPhone() + "</td>");
                    out.println("<td>" + record.getDate() + "</td>");
                    out.println("<td>" + record.getService() + "</td>");
                    out.println("<td>" + record.getPayment() + "</td>");
                    out.println("<td>");
                    out.println("<button onclick='editRecord(" + record.getId() + ")'>Edit</button>");
                    out.println("<button onclick='deleteRecord(" + record.getId() + ")'>Delete</button>");
                    out.println("</td>");
                    out.println("</tr>");
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(CleaningServicesServlet.class.getName()).log(Level.SEVERE, null, ex);
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, ex.getMessage());
        }
    }
}





