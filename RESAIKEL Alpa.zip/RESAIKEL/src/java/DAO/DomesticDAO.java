package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Domestic;

public class DomesticDAO {
    private static final String JDBC_URL = "jdbc:derby://localhost:1527/customer_resaikel";
    private static final String JDBC_USER = "app";
    private static final String JDBC_PASSWORD = "app";

    
      public int getDomesticWasteCount() throws SQLException {
    int count = 0;
    String query = "SELECT COUNT(*) AS count FROM APP.DOMESTICWASTE";
    
    try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
         PreparedStatement ps = conn.prepareStatement(query);
         ResultSet rs = ps.executeQuery()) {
        
        if (rs.next()) {
            count = rs.getInt("count");
        }
    }
    
    return count;
}
       
   public void addRecord(Domestic domestic) throws SQLException {
    try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
         PreparedStatement ps = conn.prepareStatement("INSERT INTO APP.DOMESTICWASTE (NAME, ADDRESS, PHONENUMBER, DAY) VALUES (?, ?, ?, ?)")) {
        ps.setString(1, domestic.getName());
        ps.setString(2, domestic.getAddress());
        ps.setString(3, domestic.getPhone());
        ps.setString(4, domestic.getDay());
        ps.executeUpdate();

        // Optionally, you can commit the transaction if not using auto-commit
        // conn.commit();
    }
}


    public void updateRecord(Domestic service) throws SQLException {
        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             PreparedStatement ps = conn.prepareStatement("UPDATE APP.DOMESTICWASTE SET NAME=?, ADDRESS=?, PHONE=?, DAY=? WHERE ID=?")) {
            ps.setString(1, service.getName());
            ps.setString(2, service.getAddress());
            ps.setString(3, service.getPhone());
            ps.setString(4, service.getDay());
            ps.setInt(5, service.getId());
            ps.executeUpdate();
        }
    }

    public void deleteRecord(int id) throws SQLException {
        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             PreparedStatement ps = conn.prepareStatement("DELETE FROM APP.DOMESTICWASTE WHERE ID=?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public Domestic getRecordById(int id) throws SQLException {
        Domestic domestic = null;
        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM APP.DOMESTICWASTE WHERE ID=?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    domestic = new Domestic(
                        rs.getInt("ID"),
                        rs.getString("NAME"),
                        rs.getString("ADDRESS"),
                        rs.getString("PHONE"),
                        rs.getString("DAY")
                    );
                }
            }
        }
        return domestic;
    }

    public List<Domestic> getAllRecords() throws SQLException {
        List<Domestic> domestics = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM APP.DOMESTICWASTE")) {
            while (rs.next()) {
                Domestic domestic = new Domestic(
                    rs.getInt("ID"),
                    rs.getString("NAME"),
                    rs.getString("ADDRESS"),
                    rs.getString("PHONE"),
                    rs.getString("DAY")
                );
                domestics.add(domestic);
            }
        }
        return domestics;
    }
}


