package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import model.CleaningService;

public class CleaningServicesDAO {
    private static final String JDBC_URL = "jdbc:derby://localhost:1527/customer_resaikel";
    private static final String JDBC_USER = "app";
    private static final String JDBC_PASSWORD = "app";

    public int getCleaningServiceCount() throws SQLException {
    int count = 0;
    String query = "SELECT COUNT(*) AS count FROM APP.CLEANINGSERVICES";
    
    try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
         PreparedStatement ps = conn.prepareStatement(query);
         ResultSet rs = ps.executeQuery()) {
        
        if (rs.next()) {
            count = rs.getInt("count");
        }
    }
    
    return count;
}
    
    public void addRecord(CleaningService service) throws SQLException {
        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             PreparedStatement ps = conn.prepareStatement("INSERT INTO APP.CLEANINGSERVICES (NAME, ADDRESS, PHONENUMBER, DATE, SERVICE, PAYMENT) VALUES (?, ?, ?, ?, ?, ?)")) {
            ps.setString(1, service.getName());
            ps.setString(2, service.getAddress());
            ps.setString(3, service.getPhone());
            ps.setDate(4, java.sql.Date.valueOf(service.getDate()));
            ps.setString(5, service.getService());
            ps.setString(6, service.getPayment());
            ps.executeUpdate();
        }
    }

    public void updateRecord(CleaningService service) throws SQLException {
        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             PreparedStatement ps = conn.prepareStatement("UPDATE APP.CLEANINGSERVICES SET NAME=?, ADDRESS=?, PHONENUMBER=?, DATE=?, SERVICE=?, PAYMENT=? WHERE ID=?")) {
            ps.setString(1, service.getName());
            ps.setString(2, service.getAddress());
            ps.setString(3, service.getPhone());
            ps.setDate(4, java.sql.Date.valueOf(service.getDate()));
            ps.setString(5, service.getService());
            ps.setString(6, service.getPayment());
            ps.setInt(7, service.getId());
            ps.executeUpdate();
        }
    }

    public void deleteRecord(int id) throws SQLException {
        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             PreparedStatement ps = conn.prepareStatement("DELETE FROM APP.CLEANINGSERVICES WHERE ID=?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public CleaningService getRecordById(int id) throws SQLException {
        CleaningService service = null;
        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM APP.CLEANINGSERVICES WHERE ID=?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    service = new CleaningService(
                        rs.getInt("ID"),
                        rs.getString("NAME"),
                        rs.getString("ADDRESS"),
                        rs.getString("PHONENUMBER"),
                        rs.getDate("DATE").toString(),
                        rs.getString("SERVICE"),
                        rs.getString("PAYMENT")
                    );
                }
            }
        }
        return service;
    }

    public List<CleaningService> getAllRecords() throws SQLException {
        List<CleaningService> services = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM APP.CLEANINGSERVICES")) {
            while (rs.next()) {
                CleaningService service = new CleaningService(
                    rs.getInt("ID"),
                    rs.getString("NAME"),
                    rs.getString("ADDRESS"),
                    rs.getString("PHONENUMBER"),
                    rs.getDate("DATE").toString(),
                    rs.getString("SERVICE"),
                    rs.getString("PAYMENT")
                );
                services.add(service);
            }
        }
        return services;
    }
}
